void main() {
  double tugas = 85; // Nilai tugas
  double uts = 78;   // Nilai UTS
  double uas = 90;   // Nilai UAS

  double nilaiAkhir = (tugas * 0.4) + (uts * 0.3) + (uas * 0.3);

  String grade;
  if (nilaiAkhir >= 80) {
    grade = "A";
  } else if (nilaiAkhir >= 70) {
    grade = "B";
  } else if (nilaiAkhir >= 60) {
    grade = "C";
  } else if (nilaiAkhir >= 50) {
    grade = "D";
  } else {
    grade = "E";
  }

  // Menampilkan hasil
  print("Nilai Tugas: $tugas");
  print("Nilai UTS: $uts");
  print("Nilai UAS: $uas");
  print("Nilai Akhir: $nilaiAkhir");
  print("Grade: $grade");
}
